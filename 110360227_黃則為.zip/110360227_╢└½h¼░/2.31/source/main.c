#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i,j,k;
	printf("number\tsquare\tcube\n");
	for (i = 0; i < 11; i++) {
		
		j = i * i;
		k = j * i;
		printf("%d\t%d\t%d\n",i,j,k);
		
	}
	return 0;
}