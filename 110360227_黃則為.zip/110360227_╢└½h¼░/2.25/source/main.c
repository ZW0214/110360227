#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	printf("HHHHHHHHH\n");
	printf("    H    \n");
	printf("    H    \n");
	printf("    H    \n");
	printf("HHHHHHHHH\n\n");
	printf("Z       Z\n");
	printf("Z Z     Z\n");
	printf("Z   Z   Z\n");
	printf("Z     Z Z\n");
	printf("Z       Z\n\n");
	printf("WWWWWWWWW\n");
	printf("  W      \n");
	printf("    WWWWW\n");
	printf("  W      \n");
	printf("WWWWWWWWW\n");
	return 0;
}