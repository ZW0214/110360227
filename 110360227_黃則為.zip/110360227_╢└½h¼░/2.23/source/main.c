#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int x,y,z,l,s;
	printf("press three integer:");
	scanf_s("%d%d%d",&x,&y,&z);
	s = x;
	l = y;
	if (y < s)
	{
		s = y;
	}

	if (z < s )
	{
		s  = z;
	}
	if (z > l )
	{
		l  = z;
	}

	if (y > l )
	{
		l  = y;
	}
	printf("largest is :%d\nsmallest is :%d\n", l, s);
	return 0;
}

